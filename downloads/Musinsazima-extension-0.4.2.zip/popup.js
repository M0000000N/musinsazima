const $ = id => document.getElementById(id);
const buttons = [...document.querySelectorAll('button')];
let pending = false;

async function send(action) {
  const response = await chrome.runtime.sendMessage({ type: 'musinsazima-popup', action });
  if (!response?.ok) throw new Error(response?.error || '확장 프로그램에 연결하지 못했어요. 다시 눌러 주세요.');
  return response.data;
}

function render(data) {
  const job = data?.applicationJob || data?.job;
  const enabled = data?.settings?.enabled === true;
  if (job?.status === 'running' || job?.status === 'queued') {
    $('status').textContent = job.status === 'queued' ? '신청을 준비하고 있어요' : '체험단을 신청하고 있어요';
    if (Number.isSafeInteger(job.confirmed) && Number.isSafeInteger(job.target)) $('description').textContent = `${job.target}건 중 ${job.confirmed}건 신청을 마쳤어요. 자세한 내용은 관리 화면에서 확인해 주세요.`;
  } else {
    $('status').textContent = enabled ? '자동 신청이 켜져 있어요' : '관리 화면에서 시작해 주세요';
    $('description').textContent = '신청 조건과 진행 상황은 관리 화면에서 확인할 수 있어요.';
  }
}

async function act(action, closeAfter = false) {
  if (pending) return;
  pending = true;
  buttons.forEach(button => { button.disabled = true; });
  $('error').hidden = true;
  try {
    const data = await send(action);
    if (closeAfter) { window.close(); return; }
    if (action === 'stop') {
      $('status').textContent = '자동 신청을 중지했어요';
      $('description').textContent = '다시 시작하려면 관리 화면에서 자동 신청을 켜 주세요.';
    } else render(data);
  } catch (error) {
    $('status').textContent = '잠시 연결이 끊겼어요';
    $('error').textContent = error instanceof Error ? error.message : '다시 눌러 주세요.';
    $('error').hidden = false;
  } finally {
    pending = false;
    buttons.forEach(button => { button.disabled = false; });
  }
}

$('dashboard').addEventListener('click', () => void act('open-dashboard', true));
$('connect').addEventListener('click', () => void act('connect', true));
$('stop').addEventListener('click', () => void act('stop'));
void act('status');
