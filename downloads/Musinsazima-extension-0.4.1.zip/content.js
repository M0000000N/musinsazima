"use strict";
(() => {
  // src/policy.ts
  var decision = (action, reason, option = null) => ({ action, reason, option });
  var normalizeSize = (size) => (size ?? "").trim().toUpperCase().replace(/\s+/g, "");
  var isFreeSize = (size) => ["FREE", "F", "ONESIZE", "OS", "\uD504\uB9AC", "\uD504\uB9AC\uC0AC\uC774\uC988"].includes(normalizeSize(size));
  var isFixedOption = (option) => "fixedOption" in option && option.fixedOption === true;
  function forbiddenBottom(option, priorities = []) {
    const labels = [option.size ?? ""];
    try {
      const parts = JSON.parse(option.id);
      if (Array.isArray(parts)) labels.push(...parts.filter((part) => typeof part === "string"));
    } catch {
      labels.push(option.label);
    }
    const explicitlyAllowed = new Set(priorities.map(normalizeSize));
    return labels.some((label) => {
      const range = /^(\d{2})(?:~|-|–|—)(\d{2})$/.exec(normalizeSize(label));
      if (range) return [26, 27].some((size) => size >= Number(range[1]) && size <= Number(range[2]) && !explicitlyAllowed.has(String(size)));
      return [...label.matchAll(/(?<!\d)(26|27)(?!\d)/g)].some((match) => !explicitlyAllowed.has(match[1]));
    });
  }
  function numericRange(option) {
    let last = option.size ?? "";
    try {
      const parts = JSON.parse(option.id);
      if (Array.isArray(parts) && typeof parts.at(-1) === "string") last = parts.at(-1);
    } catch {
    }
    return /^\d+\s*(?:~|-|–|—)\s*\d+$/.test(last);
  }
  function includesExplicitUpperSize(candidate, wanted) {
    const value = normalizeSize(candidate);
    const parts = value === "SM" ? ["S", "M"] : value.split(/[-/]/);
    const letter = /^(?:XXS|XS|S|M|L|XL|XXL|2XL|3XL)$/;
    return parts.length === 2 && parts.every((part) => letter.test(part)) && parts.includes(normalizeSize(wanted));
  }
  function preferredSizes(event, settings) {
    const extra = event.id ? settings.additionalSizesByEvent?.[event.id] ?? [] : [];
    const withApproved = (sizes) => [.../* @__PURE__ */ new Set([...sizes, ...extra])];
    if (event.category === "shoes") return withApproved(settings.shoeSizes);
    if (event.category !== "clothing") return null;
    if (!event.clothingType || event.clothingType === "unknown") return [];
    if (event.clothingType === "other") return withApproved(settings.clothingSizes);
    if (event.targetGender === "women" || event.targetGender === "unisex") return withApproved(settings.womenBottomSizes);
    if (event.targetGender === "men") return withApproved(settings.menBottomSizes);
    return [];
  }
  function permittedBottomRange(size, priorities) {
    const range = /^(\d{2})(?:~|-|–|—)(\d{2})$/.exec(normalizeSize(size));
    if (!range) return null;
    const start = Number(range[1]), end = Number(range[2]);
    if (start > end || end - start > 10) return null;
    const allowed = new Set(priorities.map(normalizeSize));
    for (let value = start; value <= end; value++) if (!allowed.has(String(value))) return null;
    return [start, end];
  }
  function evaluateEvent(event, settings, now = /* @__PURE__ */ new Date()) {
    if (settings.excludedEventIds?.includes(event.id)) return decision("skip", "\uC0AC\uC6A9\uC790\uAC00 \uC81C\uC678\uD55C \uC0C1\uD488\uC785\uB2C8\uB2E4.");
    if (event.category === "kids" || settings.excludedCategories.includes(event.category)) return decision("skip", "\uC81C\uC678\uD55C \uCE74\uD14C\uACE0\uB9AC\uC785\uB2C8\uB2E4.");
    if (event.status === "applied") return decision("skip", "\uC774\uBBF8 \uC2E0\uCCAD\uD55C \uCCB4\uD5D8\uB2E8\uC785\uB2C8\uB2E4.");
    if (event.status === "closed") return decision("skip", "\uBAA8\uC9D1\uC774 \uC885\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    if (event.status !== "open") return decision("hold", event.reason || "\uC2E0\uCCAD \uBC84\uD2BC \uB610\uB294 \uBAA8\uC9D1 \uC0C1\uD0DC\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    if (event.deadline) {
      const deadline = Date.parse(event.deadline);
      if (!Number.isFinite(deadline)) return decision("hold", "\uB9C8\uAC10 \uC2DC\uAC04\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
      if (deadline <= now.getTime()) return decision("skip", "\uC2E0\uCCAD \uB9C8\uAC10 \uC2DC\uAC04\uC774 \uC9C0\uB0AC\uC2B5\uB2C8\uB2E4.");
    }
    if (event.category === "unknown") return decision("hold", "\uC0C1\uD488 \uCE74\uD14C\uACE0\uB9AC\uB97C \uD655\uC778\uD574\uC57C \uD569\uB2C8\uB2E4.");
    if (event.eligible === false) return decision("hold", event.reason || "\uBB34\uC2E0\uC0AC\uC5D0\uC11C \uC774 \uACC4\uC815\uC758 \uC2E0\uCCAD\uC744 \uD5C8\uC6A9\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    if (event.requiresManualReview) return decision("hold", event.reason || "\uCD94\uAC00 \uC785\uB825 \uB610\uB294 \uD655\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.");
    if (event.eligible !== true) return decision("hold", event.reason || "\uC2E0\uCCAD \uD654\uBA74\uC744 \uB05D\uAE4C\uC9C0 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const rawInStock = event.options.filter((option2) => option2.available);
    const priorities = preferredSizes(event, settings);
    const inStock = rawInStock.filter((option2) => event.category !== "clothing" || event.clothingType === "other" || !forbiddenBottom(option2, priorities ?? []));
    if (rawInStock.length > 0 && inStock.length === 0) return decision("hold", "\uC120\uD0DD \uAC00\uB2A5\uD55C \uC635\uC158\uC5D0 \uC81C\uC678\uD55C 26\xB727 \uD45C\uC2DC\uAC00 \uC788\uC5B4 \uC2E0\uCCAD\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    const explicitlyApproved = event.category === "shoes" ? void 0 : inStock.find((option2) => option2.explicitApproval?.eventId === event.id && option2.explicitApproval.optionId === option2.id);
    if (explicitlyApproved) return decision("apply", "\uC774 \uC0C1\uD488\uC5D0\uC11C \uC9C1\uC811 \uC2B9\uC778\uD55C \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", explicitlyApproved);
    const isBottoms = event.category === "clothing" && event.clothingType === "bottoms";
    const freeClothingAllowed = event.category === "clothing" && settings.allowFreeSize && inStock.length > 0 && inStock.every((option2) => isFreeSize(option2.size));
    if (freeClothingAllowed) return decision("apply", "\uC120\uD0DD \uAC00\uB2A5\uD55C \uC0AC\uC774\uC988\uAC00 \uD504\uB9AC\uBFD0\uC774\uC5B4\uC11C \uCCAB \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", inStock[0]);
    const fixedClothing = event.category === "clothing" && inStock.length > 0 && inStock.every((option2) => isFixedOption(option2) && option2.size === null);
    if (fixedClothing) return decision("apply", "\uBCC4\uB3C4 \uC0AC\uC774\uC988 \uC120\uD0DD\uC774 \uC5C6\uB294 \uC0C1\uD488\uC774\uC5B4\uC11C \uCCAB \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", inStock[0]);
    const singleClothing = event.category === "clothing" && inStock.length === 1 && !isFreeSize(inStock[0].size) && !numericRange(inStock[0]) && (event.clothingType === "other" || !forbiddenBottom(inStock[0], priorities ?? []));
    const available = inStock.filter((option2) => event.category !== "clothing" || !isFreeSize(option2.size) || freeClothingAllowed);
    let individuallyApproved;
    for (const size of settings.additionalSizesByEvent?.[event.id] ?? []) {
      individuallyApproved = available.find((option2) => option2.size !== null && normalizeSize(option2.size) === normalizeSize(size));
      if (individuallyApproved) break;
    }
    if (event.category === "clothing" && (!event.clothingType || event.clothingType === "unknown")) {
      if (individuallyApproved) return decision("apply", `\uC774 \uC0C1\uD488\uC5D0 \uC9C1\uC811 \uD5C8\uC6A9\uD55C ${individuallyApproved.size} \uC0AC\uC774\uC988\uB97C \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.`, individuallyApproved);
      if (singleClothing) return decision("apply", "\uC2E0\uCCAD \uAC00\uB2A5\uD55C \uC635\uC158\uC774 \uD55C \uAC1C\uC5EC\uC11C \uD574\uB2F9 \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", inStock[0]);
      return decision("hold", "\uC5EC\uB7EC \uC0AC\uC774\uC988 \uC911 \uC5B4\uB5A4 \uAE30\uC900\uC744 \uC801\uC6A9\uD560\uC9C0 \uC0C1\uD488 \uC815\uBCF4\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    }
    if (isBottoms && !["women", "men", "unisex"].includes(event.targetGender ?? "unknown")) {
      if (individuallyApproved) return decision("apply", `\uC774 \uC0C1\uD488\uC5D0 \uC9C1\uC811 \uD5C8\uC6A9\uD55C ${individuallyApproved.size} \uC0AC\uC774\uC988\uB97C \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.`, individuallyApproved);
      if (singleClothing) return decision("apply", "\uC2E0\uCCAD \uAC00\uB2A5\uD55C \uC635\uC158\uC774 \uD55C \uAC1C\uC5EC\uC11C \uD574\uB2F9 \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", inStock[0]);
      return decision("hold", "\uC5EC\uB7EC \uD558\uC758 \uC0AC\uC774\uC988 \uC911 \uC801\uC6A9\uD560 \uAE30\uC900\uC758 \uC131\uBCC4 \uC815\uBCF4\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    }
    if (priorities) {
      for (const size of priorities) {
        const option2 = available.find((candidate) => {
          if (normalizeSize(candidate.size) === normalizeSize(size)) return true;
          if (event.category === "clothing" && event.clothingType === "other" && includesExplicitUpperSize(candidate.size, size)) return true;
          if (!isBottoms || event.targetGender === "men" || !/^\d{2}$/.test(normalizeSize(size))) return false;
          const range = permittedBottomRange(candidate.size, priorities);
          return range !== null && Number(size) >= range[0] && Number(size) <= range[1];
        });
        if (option2) return decision("apply", `${normalizeSize(option2.size) === normalizeSize(size) ? size : option2.label} \uC0AC\uC774\uC988\uB97C \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.`, option2);
      }
      if (singleClothing) return decision("apply", "\uC2E0\uCCAD \uAC00\uB2A5\uD55C \uC635\uC158\uC774 \uD55C \uAC1C\uC5EC\uC11C \uD574\uB2F9 \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", inStock[0]);
      const sizes = [...new Set(inStock.map((option2) => option2.size?.trim() || option2.label.trim() || "\uC0AC\uC774\uC988 \uBBF8\uD655\uC778"))];
      const availableSizes = sizes.slice(0, 8).map((size) => size.slice(0, 32)).join(", ") || "\uC5C6\uC74C";
      return decision("hold", `\uD5C8\uC6A9\uB41C \uC0AC\uC774\uC988\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uD604\uC7AC \uC120\uD0DD \uAC00\uB2A5: ${availableSizes}${sizes.length > 8 ? " \uC678" : ""}.`);
    }
    const option = available[0];
    return option ? decision("apply", "\uCCAB \uBC88\uC9F8 \uC2E0\uCCAD \uAC00\uB2A5\uD55C \uC635\uC158\uC744 \uC120\uD0DD\uD588\uC2B5\uB2C8\uB2E4.", option) : decision("hold", "\uC2E0\uCCAD \uAC00\uB2A5\uD55C \uC635\uC158\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
  }

  // src/consents.ts
  var CURRENT_CONSENT_VERSION = "musinsa-preuser-required-2026-10-29";
  function hasCurrentApplicationConsent(settings) {
    return settings.applicationConsent === true && settings.consentPolicyVersion === CURRENT_CONSENT_VERSION && typeof settings.consentApprovedAt === "string" && Number.isFinite(Date.parse(settings.consentApprovedAt));
  }

  // src/domain.ts
  var DELIVERY_REQUEST_OPTIONS = ["", "\uBB38 \uC55E\uC5D0 \uB194\uC8FC\uC138\uC694", "\uACBD\uBE44\uC2E4\uC5D0 \uB9E1\uACA8\uC8FC\uC138\uC694", "\uD0DD\uBC30\uD568\uC5D0 \uB123\uC5B4\uC8FC\uC138\uC694", "\uBC30\uC1A1 \uC804 \uC5F0\uB77D \uC8FC\uC138\uC694"];

  // src/ordering.ts
  function deadlineFromBadge(label, now = /* @__PURE__ */ new Date()) {
    if (!Number.isFinite(now.getTime())) return null;
    const badge = label.normalize("NFKC").replace(/\s+/g, "").toUpperCase();
    const match = /^D-(\d{1,3})$/.exec(badge);
    const days = badge === "\uC624\uB298\uB9C8\uAC10" ? 0 : match ? Number(match[1]) : null;
    if (days === null || days > 365) return null;
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Seoul",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(now);
    const part = (name) => Number(parts.find((item) => item.type === name)?.value);
    const day = new Date(Date.UTC(part("year"), part("month") - 1, part("day") + days));
    return `${day.toISOString().slice(0, 10)}T23:59:59.999+09:00`;
  }
  function sortEventsByDeadline(events) {
    const time = (deadline) => {
      const parsed = deadline ? Date.parse(deadline) : NaN;
      return Number.isFinite(parsed) ? parsed : Number.POSITIVE_INFINITY;
    };
    return events.map((event, index) => ({ event, index, deadline: time(event.deadline) })).sort((left, right) => left.deadline === right.deadline ? left.index - right.index : left.deadline < right.deadline ? -1 : 1).map((item) => item.event);
  }

  // extension/content.ts
  var ORIGIN = "https://www.musinsa.com";
  var CARDS = '[data-content-type="preuser"][data-section-name="preuser_content_list"][data-content-id]';
  var DROPDOWN = '[class*="Dropdown__DropdownBox"]';
  var CHOICE = 'li[class*="Dropdown__DropdownItem"]';
  var CONSENT_MODAL = '[class*="ConsentDetailModal__Container"]';
  var APPLY = /^신청하기(?:\s*\d{2}:[0-5]\d:[0-5]\d\s*남음)?$/;
  var APPLIED = /^(?:신청 취소|신청취소|신청 완료|신청완료|신청 내역 확인)$/;
  var REQUIRED = [
    { id: "privacy_collection", label: "[\uD544\uC218] \uAC1C\uC778\uC815\uBCF4 \uC218\uC9D1 \uBC0F \uC774\uC6A9 \uB3D9\uC758", hash: "48ae4ee0c5b7c8e9ca41df4545c4e5139ad53803f5391a7ccffeb17fcaba1d18" },
    { id: "privacy_third_party", label: "[\uD544\uC218] \uAC1C\uC778\uC815\uBCF4 \uC81C 3\uC790 \uC81C\uACF5 \uB3D9\uC758", hash: "92f92f11eb6956919a73b9ff390c8da75d581259cdd3b15a772600f72fbf7be5" },
    { id: "penalty_policy", label: "[\uD544\uC218] \uC774\uBCA4\uD2B8 \uB2F9\uCCA8\uC790\uC758 \uD328\uB110\uD2F0 \uC815\uCC45 \uB3D9\uC758", hash: "ed023314683aba51de703edfe85f1e7e60f4e1490ed820f3a5bf2aa8e6f174f6" },
    { id: "auto_payment", label: "[\uD544\uC218] \uC774\uBCA4\uD2B8 \uB2F9\uCCA8 \uC2DC '0\uC6D0 \uC790\uB3D9 \uACB0\uC81C' \uB3D9\uC758", hash: "1dc7f54ccd2a2c901f6c99aa97b184d946b0168e76428ff4917703023139e37b" }
  ];
  var prepared = null;
  var inspectionState = null;
  var deferredEffect = null;
  var busy = false;
  var normalize = (value) => value.normalize("NFKC").replace(/\s+/g, " ").trim();
  var compact = (value) => normalize(value).toUpperCase().replace(/\s+/g, "");
  var nodes = (selector, parent = document) => Array.from(parent.querySelectorAll(selector));
  var visible = (element) => element instanceof HTMLElement && !element.hidden && getComputedStyle(element).display !== "none" && getComputedStyle(element).visibility !== "hidden" && element.getClientRects().length > 0;
  var text = (element) => element?.textContent?.trim() ?? "";
  var buttons = (name, parent = document) => nodes('button,[role="button"]', parent).filter((element) => visible(element) && (typeof name === "string" ? normalize(text(element)) === name : name.test(normalize(text(element)))));
  var enabled = (element) => element.getAttribute("aria-disabled") !== "true" && !element.hasAttribute("disabled");
  function one(values, reason) {
    if (values.length !== 1) throw new Error(reason);
    return values[0];
  }
  function click(element) {
    if (!visible(element) || !enabled(element)) throw new Error("\uC120\uD0DD\uD55C \uBC84\uD2BC\uC774\uB098 \uC635\uC158\uC744 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    element.click();
  }
  function officialPath(pattern) {
    const url = new URL(location.href);
    const match = pattern.exec(url.pathname);
    if (url.origin !== ORIGIN || url.username || url.password || !match || window.top !== window) throw new Error("\uACF5\uC2DD \uBB34\uC2E0\uC0AC \uD654\uBA74\uC5D0\uC11C\uB9CC \uC9C4\uD589\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.");
    return match;
  }
  function eventPath(event, form = false) {
    if (!event || !/^\d+$/.test(event.id)) throw new Error("\uCCB4\uD5D8\uB2E8 \uC2DD\uBCC4\uC790\uB97C \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    const url = new URL(event.url);
    if (url.origin !== ORIGIN || url.username || url.password || !new RegExp(`^/preuser/events/${event.id}/?$`).test(url.pathname)) throw new Error("\uCCB4\uD5D8\uB2E8 \uC8FC\uC18C\uAC00 \uC77C\uCE58\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const match = officialPath(form ? /^\/preuser\/apply\/(\d+)\/?$/ : /^\/preuser\/events\/(\d+)\/?$/);
    if (match[1] !== event.id) throw new Error("\uB2E4\uB978 \uCCB4\uD5D8\uB2E8 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD574 \uC791\uC5C5\uC744 \uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4.");
    return `${ORIGIN}/preuser/${form ? "apply" : "events"}/${event.id}`;
  }
  async function waitFor(read, timeout = 15e3) {
    const initial = read();
    if (initial) return initial;
    return new Promise((resolvePromise, rejectPromise) => {
      const observer = new MutationObserver(check);
      const timer = setTimeout(() => {
        cleanup();
        rejectPromise(new Error("\uBB34\uC2E0\uC0AC \uD654\uBA74 \uC751\uB2F5\uC774 \uB2A6\uC5B4 \uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uD655\uC778\uD574 \uC8FC\uC138\uC694."));
      }, timeout);
      function cleanup() {
        clearTimeout(timer);
        observer.disconnect();
      }
      function check() {
        try {
          const value = read();
          if (value) {
            cleanup();
            resolvePromise(value);
          }
        } catch (error) {
          cleanup();
          rejectPromise(error);
        }
      }
      observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
      check();
    });
  }
  async function hash(value) {
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function parseDeadline(value) {
    const match = [...value.matchAll(/(\d{2,4})\.(\d{1,2})\.(\d{1,2})/g)].at(-1);
    if (!match) return null;
    const year = Number(match[1]) + (match[1].length === 2 ? 2e3 : 0);
    const month = Number(match[2]);
    const day = Number(match[3]);
    if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate()) return null;
    return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}T23:59:59.999+09:00`;
  }
  function sizeFromLabel(label, category) {
    const value = normalize(label).toUpperCase();
    if (category === "clothing" && /^S\s*(?:[-/]\s*)?M$/.test(value)) return "SM";
    if (category === "clothing" && /^0\d{2}$/.test(value)) return String(Number(value));
    if (category === "clothing" && /^(?:SIZE\s*\d{1,2}|\d{1,2}\s*(?:SIZE|사이즈))$/.test(value)) return value.replace(/\s+/g, "");
    if (category === "clothing") {
      const combined = /^(XXS|XS|S|M|L|XL|XXL|2XL|3XL)\s*[-/]\s*(XXS|XS|S|M|L|XL|XXL|2XL|3XL)$/.exec(value);
      if (combined) return `${combined[1]}-${combined[2]}`;
      const colorSize = /^.+_(XXS|XS|S|M|L|XL|XXL|2XL|3XL)$/.exec(value);
      if (colorSize) return colorSize[1];
      if (/^\d{1,2}(?:\s*SIZE)?$/.test(value)) return value.replace(/\s+/g, "");
    }
    const shoe = /^(\d{3})(?:\s*MM|\s*\(\s*\d{1,3}(?:\.\d+)?\s*\))?$/.exec(value);
    if (shoe) return shoe[1];
    const explicit = /^\d{1,3}\s*\(\s*(XXS|XS|S|M|L|XL|XXL|2XL|3XL)\s*\)$/.exec(value);
    if (explicit) return explicit[1];
    if (/^(?:26|27|28|30)$/.test(value)) return value;
    if (/^\d{2}\s*(?:~|-|–|—)\s*\d{2}$/.test(value)) return value.replace(/\s+/g, "");
    if (/^(?:L|LARGE|라지)(?:\s*\([^)]*\))?$/.test(value)) return "L";
    if (/^(?:FREE|F|ONE SIZE|OS|프리|프리사이즈)$/.test(value)) return "FREE";
    return /^(?:XXS|XS|S|M|XL|XXL|2XL|3XL)$/.test(value) ? value : null;
  }
  function safeProductUrl(value) {
    const url = new URL(value);
    if (url.origin !== ORIGIN || url.username || url.password || !/^\/products\/\d+\/?$/.test(url.pathname)) throw new Error("\uACF5\uC2DD \uC0C1\uD488 \uC8FC\uC18C\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    return `${ORIGIN}${url.pathname.replace(/\/$/, "")}`;
  }
  async function eventInformation(event) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1e4);
    try {
      const url = `${ORIGIN}/preuser/api/v1/event/events/${event.id}`;
      const response = await fetch(url, { method: "GET", credentials: "same-origin", redirect: "error", signal: controller.signal });
      if (!response.ok || response.url && response.url !== url) throw new Error("\uACF5\uC2DD \uCCB4\uD5D8\uB2E8 \uC0C1\uD488 \uC815\uBCF4\uB97C \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      const body = await response.json();
      const data = body?.data;
      if (!data || String(data.eventId) !== event.id || typeof data.eventCategory !== "string" || !Array.isArray(data.products) || data.products.length < 1 || data.products.length > 100) throw new Error("\uCCB4\uD5D8\uB2E8 \uC0C1\uD488 \uC815\uBCF4\uC758 \uAD6C\uC131\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
      const products = data.products.map((product) => ({
        name: typeof product?.name === "string" ? product.name : "",
        url: safeProductUrl(product?.link),
        optionItems: Array.isArray(product?.optionItems) ? product.optionItems.slice(0, 200).map((item) => ({ activated: item?.activated === true, isDeleted: item?.isDeleted !== false, outOfStock: item?.outOfStock !== false, optionValues: Array.isArray(item?.optionValues) ? item.optionValues.slice(0, 4).map((value) => ({ name: typeof value?.name === "string" ? value.name : "", optionName: typeof value?.optionName === "string" ? value.optionName : "" })) : [] })) : []
      }));
      if (new Set(products.map((product) => product.url)).size > 20) throw new Error("\uC0C1\uD488 \uD655\uC778 \uBC94\uC704\uB97C \uCD08\uACFC\uD588\uC2B5\uB2C8\uB2E4.");
      return { category: data.eventCategory, products };
    } finally {
      clearTimeout(timer);
    }
  }
  async function readProduct() {
    officialPath(/^\/products\/\d+\/?$/);
    const breadcrumb = await waitFor(() => nodes('[class*="Category__CategoryList"] a[href]').length ? nodes('[class*="Category__CategoryList"] a[href]') : null, 8e3);
    const labels = breadcrumb.map((element) => normalize(text(element)));
    const kids = labels.includes("\uD0A4\uC988");
    const shoes = labels.includes("\uC2E0\uBC1C");
    const clothing = labels.some((label) => ["\uC0C1\uC758", "\uC544\uC6B0\uD130", "\uBC14\uC9C0", "\uD558\uC758", "\uC6D0\uD53C\uC2A4", "\uC2A4\uCEE4\uD2B8", "\uC6D0\uD53C\uC2A4/\uC2A4\uCEE4\uD2B8", "\uC18D\uC637/\uD648\uC6E8\uC5B4"].includes(label));
    const sportsAccessory = labels.includes("\uC2A4\uD3EC\uCE20/\uB808\uC800") && labels.includes("\uC7A1\uD654") && labels.some((label) => ["\uC6CC\uBA38", "\uBC18\uB2E4\uB098/\uD5E4\uC5B4\uBC34\uB4DC/\uAC70\uD2B8"].includes(label));
    const other = sportsAccessory || labels.some((label) => ["\uBAA8\uC790", "\uCEA1/\uC57C\uAD6C\uBAA8\uC790", "\uC18C\uD488", "\uBA38\uD50C\uB7EC", "\uBDF0\uD2F0", "\uAC00\uBC29", "\uD328\uC158 \uC18C\uD488", "\uB514\uC9C0\uD138/\uB77C\uC774\uD504"].includes(label));
    const category = kids ? "kids" : Number(shoes) + Number(clothing) + Number(other) === 1 ? shoes ? "shoes" : clothing ? "clothing" : "other" : "unknown";
    const bottoms = labels.some((label) => ["\uBC14\uC9C0", "\uD558\uC758", "\uC2A4\uCEE4\uD2B8", "\uB871\uC2A4\uCEE4\uD2B8", "\uBBF8\uB514\uC2A4\uCEE4\uD2B8"].includes(label));
    const dress = labels.includes("\uC6D0\uD53C\uC2A4") || labels.includes("\uB9E5\uC2DC\uC6D0\uD53C\uC2A4");
    const upper = labels.some((label) => ["\uC0C1\uC758", "\uC544\uC6B0\uD130"].includes(label));
    const clothingType = category !== "clothing" ? "unknown" : bottoms && !upper && !dress ? "bottoms" : (dress || upper) && !bottoms ? "other" : "unknown";
    let targetGender = "unknown";
    const gender = nodes("dt").filter((element) => normalize(text(element)) === "\uC131\uBCC4");
    if (gender.length === 1) {
      const parent = gender[0].parentElement;
      if (parent?.children.length === 2 && parent.children[0] === gender[0] && parent.children[1]?.tagName === "DD") {
        const value = normalize(text(parent.children[1]));
        targetGender = value === "\uC5EC" ? "women" : value === "\uB0A8" ? "men" : value === "\uACF5\uC6A9" || value === "\uB0A8\uB140\uACF5\uC6A9" || /^남\s*[,/·・]\s*여$/.test(value) ? "unisex" : "unknown";
      }
    }
    return { url: safeProductUrl(location.href), category, clothingType, targetGender };
  }
  function classified(event, information, supplied = []) {
    const category = information.category;
    if (category === "KIDS") return { event: { ...event, category: "kids" } };
    if (category === "SHOE") return { event: { ...event, category: "shoes" } };
    if (category === "BEAUTY") return { event: { ...event, category: "other" } };
    if (category === "TOP" || category === "OUTER") return { event: { ...event, category: "clothing", clothingType: "other", targetGender: "unknown" } };
    const urls = [...new Set(information.products.map((product) => product.url))];
    if (supplied.length !== urls.length || supplied.some((result) => !urls.includes(result.url)) || new Set(supplied.map((result) => result.url)).size !== urls.length) return { event: { ...event, category: category === "PANTS" ? "clothing" : "unknown", clothingType: "unknown", targetGender: "unknown" }, productUrls: urls, needsClassification: true };
    if (supplied.some((result) => result.category === "kids")) return { event: { ...event, category: "kids" } };
    const categories = new Set(supplied.map((result) => result.category));
    if (categories.size !== 1 || categories.has("unknown")) return { event: { ...event, category: "unknown", clothingType: "unknown", targetGender: "unknown" } };
    const resolved = supplied[0].category;
    if (resolved !== "clothing") return { event: { ...event, category: resolved } };
    const kinds = new Set(supplied.map((result) => result.clothingType));
    const genders = new Set(supplied.map((result) => result.targetGender));
    const kind = kinds.size === 1 && !kinds.has("unknown") ? supplied[0].clothingType : "unknown";
    const gender = genders.size === 1 && !genders.has("unknown") ? supplied[0].targetGender : "unknown";
    return { event: { ...event, category: "clothing", clothingType: category === "PANTS" && kind !== "bottoms" ? "unknown" : kind, targetGender: gender } };
  }
  async function session() {
    officialPath(/^\/preuser\/main\/?$/);
    await waitFor(() => nodes('span[data-rosetta-id="4022"][data-mds="TabTextItem"]').length, 1e4);
    const authenticated = nodes('a,button,[role="button"]').some((element) => visible(element) && normalize(text(element)) === "\uB85C\uADF8\uC544\uC6C3");
    return { authenticated, reason: authenticated ? "\uC774 \uBE0C\uB77C\uC6B0\uC800\uC758 \uBB34\uC2E0\uC0AC \uACC4\uC815\uC744 \uC5F0\uACB0\uD588\uC2B5\uB2C8\uB2E4." : "\uBB34\uC2E0\uC0AC \uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.", checkedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }
  async function catalog() {
    officialPath(/^\/preuser\/main\/?$/);
    if (new URL(location.href).searchParams.has("category")) throw new Error("\uC804\uCCB4 \uBAA8\uC9D1 \uBAA9\uB85D\uC5D0\uC11C \uB2E4\uC2DC \uC2DC\uC791\uD574 \uC8FC\uC138\uC694.");
    const totals = () => nodes("span,p,div").filter((element) => /^총\s*[\d,]+\s*개$/.test(normalize(text(element))));
    await waitFor(() => totals().length, 15e3);
    const items = /* @__PURE__ */ new Map();
    const started = Date.now();
    const inspectedAt = /* @__PURE__ */ new Date();
    let lastItemsAt = started;
    let lastProgressAt = started;
    let zeroSince;
    let previousCount = -1;
    let previousTop = -1;
    let previousHeight = -1;
    let lastExpected = null;
    for (let step = 0; step < 500 && Date.now() - started < 15e4; step++) {
      const expectedText = text(totals().at(-1) ?? null);
      const match = /^총\s*([\d,]+)\s*개$/.exec(normalize(expectedText));
      const parsed = match ? Number(match[1].replaceAll(",", "")) : NaN;
      const expected = Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : null;
      lastExpected = expected;
      const mounted = nodes(CARDS);
      for (const card of mounted) {
        const id = card.getAttribute("data-content-id") ?? "";
        if (!/^\d+$/.test(id)) continue;
        const deadline = nodes('[data-mds="Label"]', card).map((element) => deadlineFromBadge(text(element), inspectedAt)).find((value) => value !== null) ?? items.get(id)?.deadline ?? null;
        items.set(id, { id, url: `${ORIGIN}/preuser/events/${id}`, title: card.getAttribute("data-content-name")?.trim() ?? "", brand: text(card.querySelector('span[data-mds="Typography"]')), category: "unknown", deadline });
      }
      if (expected === 0 && items.size === 0) {
        zeroSince ??= Date.now();
        if (Date.now() - zeroSince >= 600) return { events: [], complete: true };
        await new Promise((resolve) => setTimeout(resolve, 200));
        continue;
      }
      zeroSince = void 0;
      if (expected !== null && expected > 0 && items.size >= expected) return { events: sortEventsByDeadline([...items.values()]), complete: true };
      const scroll = document.scrollingElement ?? document.documentElement;
      const top = scroll.scrollTop;
      const height = scroll.scrollHeight;
      const now = Date.now();
      if (items.size !== previousCount) {
        lastItemsAt = now;
        lastProgressAt = now;
      }
      if (Math.abs(top - previousTop) > 1 || height !== previousHeight) lastProgressAt = now;
      previousCount = items.size;
      previousTop = top;
      previousHeight = height;
      if (document.hidden && now - lastItemsAt >= 4e3) throw new CatalogNeedsForeground(items.size, expected);
      if (now - lastProgressAt >= 12e3) throw new Error(`\uCCB4\uD5D8\uB2E8 \uBAA9\uB85D ${items.size}\uAC1C${expected === null ? "" : ` / ${expected}\uAC1C`}\uAE4C\uC9C0\uB9CC \uD655\uC778\uD588\uC2B5\uB2C8\uB2E4. \uBAA9\uB85D\uC774 \uB05D\uAE4C\uC9C0 \uC5F4\uB9AC\uC9C0 \uC54A\uC544 \uC2E0\uCCAD\uC744 \uC2DC\uC791\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.`);
      const ids = new Set(mounted.map((card) => card.getAttribute("data-content-id")));
      window.scrollBy({ top: Math.max(300, Math.floor(window.innerHeight * 0.7)), behavior: "instant" });
      await waitFor(() => nodes(CARDS).some((card) => !ids.has(card.getAttribute("data-content-id"))), 1500).catch(() => {
      });
    }
    if (document.hidden) throw new CatalogNeedsForeground(items.size, lastExpected);
    throw new Error("\uBAA8\uC9D1 \uBAA9\uB85D \uD655\uC778 \uC2DC\uAC04\uC774 \uC9C0\uB098 \uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4.");
  }
  var CatalogNeedsForeground = class extends Error {
    code = "CATALOG_NEEDS_FOREGROUND";
    constructor(read, expected) {
      super(`\uCCB4\uD5D8\uB2E8 \uBAA9\uB85D ${read}\uAC1C${expected === null ? "" : ` / ${expected}\uAC1C`}\uB97C \uD655\uC778\uD588\uC2B5\uB2C8\uB2E4. \uBAA9\uB85D\uC744 \uACC4\uC18D \uC77D\uAE30 \uC704\uD574 \uBB34\uC2E0\uC0AC \uC791\uC5C5 \uD0ED\uC744 \uC55E\uC73C\uB85C \uC5FD\uB2C8\uB2E4.`);
    }
  };
  function eventInfo(label) {
    const candidates = nodes("span,p,dt,div").filter((element) => normalize(text(element)) === label && !Array.from(element.children).some((child) => normalize(text(child)) === label));
    return candidates.length === 1 ? text(candidates[0].parentElement?.parentElement ?? null) : "";
  }
  function fixedOption(event, information, selectedProduct) {
    const products = selectedProduct === void 0 ? information.products : information.products.filter((product2) => normalize(product2.name) === normalize(selectedProduct));
    if (products.length !== 1) return null;
    const product = products[0];
    const choices2 = product.optionItems.filter((item) => item.activated && !item.isDeleted && !item.outOfStock);
    if (!product.name.trim() || choices2.length !== 1 || choices2[0].optionValues.length < 1 || choices2[0].optionValues.length > 3) return null;
    const labels = choices2[0].optionValues;
    if (selectedProduct !== void 0 && (labels.length !== 1 || compact(labels[0].optionName) !== "NONE" || compact(labels[0].name) !== "NONE")) return null;
    const size = labels.find((value) => /^(?:SIZE|사이즈|치수|S)$/i.test(value.optionName));
    return { id: JSON.stringify(selectedProduct === void 0 ? [] : [selectedProduct]), label: [product.name, ...labels.map((value) => value.name)].join(" / "), size: size ? sizeFromLabel(size.name, event.category) : null, color: labels.find((value) => /^(?:C|COLOR|색상|컬러)$/i.test(value.optionName))?.name ?? null, available: true, ...!size ? { fixedOption: true } : {} };
  }
  async function choices(dialog, index) {
    const box = nodes(DROPDOWN, dialog)[index];
    if (!box) throw new Error("\uC0C1\uD488 \uC120\uD0DD\uB780 \uAD6C\uC131\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    click(box);
    const parent = box.parentElement;
    const items = await waitFor(() => {
      const found = nodes(CHOICE, parent).filter(visible);
      return found.length ? found : null;
    }, 5e3);
    const values = items.map((element) => ({ label: text(element), available: enabled(element) && !/품절|신청불가|선택불가|모집 종료/.test(text(element)) }));
    click(box);
    return values;
  }
  async function choose(dialog, index, value) {
    const box = nodes(DROPDOWN, dialog)[index];
    if (!box) throw new Error("\uC0C1\uD488 \uC120\uD0DD\uB780 \uAD6C\uC131\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    click(box);
    await waitFor(() => nodes(CHOICE, box.parentElement).some(visible), 5e3);
    const item = one(nodes(CHOICE, box.parentElement).filter((element) => visible(element) && text(element) === value), "\uC0C1\uD488 \uC635\uC158\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    if (/품절|신청불가|선택불가|모집 종료/.test(text(item))) throw new Error("\uC120\uD0DD\uD55C \uC635\uC158\uC744 \uB354 \uC774\uC0C1 \uC2E0\uCCAD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    click(item);
  }
  async function readOptions(dialog, event, settings, information) {
    const boxes = () => nodes(DROPDOWN, dialog);
    const count = boxes().length;
    if (count === 0) {
      const complete = buttons("\uC120\uD0DD \uC644\uB8CC", dialog);
      const fixed = fixedOption(event, information);
      if (complete.length === 1 && enabled(complete[0]) && fixed) return [fixed];
      throw new Error("\uACF5\uC2DD \uB2E8\uC77C \uC635\uC158\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    }
    if (count > 3) throw new Error("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC0C1\uD488 \uC120\uD0DD \uC591\uC2DD\uC785\uB2C8\uB2E4.");
    const prompts = boxes().map(text);
    const isSize = (value) => /^(?:size|사이즈|치수|FREE|ONE SIZE|OS|프리|프리사이즈)$/i.test(value.trim());
    const isColor = (value) => /^(?:C|COLOR|컬러|색상)(?:\s*선택)?$/i.test(value.trim());
    const explicitVariant = (value) => /^(?:C|NONE|color|컬러|색상)(?:\s*선택)?$/i.test(value.trim()) || /^(?:상품|제품|product)(?:을)?(?:\s*선택(?:해\s*주세요)?)?$/i.test(value.trim());
    const genericOption = (value) => /^(?:옵션|option)(?:을)?(?:\s*선택(?:해\s*주세요)?)?$/i.test(value.trim()) || /^선택(?:해\s*주세요)?$/.test(value.trim());
    const parentRoleKnown = count > 1 && (explicitVariant(prompts[0] ?? "") || genericOption(prompts[0] ?? "")) && !isColor(prompts[0] ?? "");
    const codedColorSize = (count === 2 || count === 3) && isColor(prompts[count - 2] ?? "") && normalize(prompts[count - 1] ?? "") === "S";
    const namedSizeSuffix = (count === 1 || count === 2 && parentRoleKnown) && normalize(prompts[count - 1] ?? "") === "S";
    const sizeIndex = codedColorSize || namedSizeSuffix ? count - 1 : prompts.findIndex(isSize);
    const colorIndex = prompts.findIndex(isColor);
    const variantOnly = sizeIndex < 0 && prompts.every((value) => explicitVariant(value) || genericOption(value));
    const explicitSizeOrder = sizeIndex > 0 && prompts.filter(isSize).length === 1 && prompts.every((value, index) => index === sizeIndex || explicitVariant(value) || genericOption(value));
    if (count > 1 && (isSize(prompts[0]) || count === 2 && !isSize(prompts[1]) && !codedColorSize && !namedSizeSuffix && !variantOnly && event.category !== "other" || count === 3 && !codedColorSize && !explicitSizeOrder && !variantOnly && (isSize(prompts[1]) || !isSize(prompts[2])))) throw new Error("\uC0C1\uD488\xB7\uC0C9\uC0C1\xB7\uC0AC\uC774\uC988 \uC120\uD0DD\uB780\uC758 \uAD6C\uBD84\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const output = [];
    let firstProduct = null;
    let verifiedFixed = false;
    const add = (labels, available, activePrompts) => {
      if (activePrompts.length !== count || labels.length !== count) throw new Error("\uC120\uD0DD \uB3C4\uC911 \uC0C1\uD488 \uC120\uD0DD\uB780 \uC218\uAC00 \uBC14\uB00C\uC5C8\uC2B5\uB2C8\uB2E4.");
      const activeCoded = (count === 2 || count === 3) && isColor(activePrompts[count - 2] ?? "") && normalize(activePrompts[count - 1] ?? "") === "S";
      const activeIndex = activeCoded ? count - 1 : activePrompts.findIndex((value, index) => !(index === 0 && parentRoleKnown) && isSize(value));
      const effective = activeIndex >= 0 ? activeIndex : sizeIndex;
      const fixedSchema = effective < 0 && activePrompts.every((value, index) => index === 0 && parentRoleKnown || explicitVariant(value));
      const literal = effective >= 0 ? effective : genericOption(activePrompts[count - 1] ?? "") ? count - 1 : -1;
      let size = literal >= 0 ? sizeFromLabel(labels[literal], event.category) : null;
      const rawShoeSize = effective >= 0 ? labels[effective] : "";
      if (size === null && event.category === "shoes" && /^\d{2}$/.test(rawShoeSize) && settings.additionalSizesByEvent?.[event.id]?.some((approved) => normalize(approved) === rawShoeSize)) size = rawShoeSize;
      const combinedColor = event.category === "clothing" && literal >= 0 ? /^(.+)_(?:XXS|XS|S|M|L|XL|XXL|2XL|3XL)$/i.exec(labels[literal])?.[1] : null;
      const sizedParent = genericOption(prompts[0] ?? "") && (sizeFromLabel(labels[0], event.category) !== null || /^\d{1,2}\s*호\s*\(/.test(labels[0]));
      output.push({ id: JSON.stringify(labels), label: labels.join(" / "), size, color: colorIndex >= 0 ? labels[colorIndex] : combinedColor || (sizeIndex === 0 ? null : labels[Math.max(0, sizeIndex - 1)] || null), available, ...fixedSchema && size === null && !sizedParent ? { fixedOption: true } : {} });
    };
    const satisfied = () => {
      if (verifiedFixed || event.category === "other" && output.some((option) => option.available)) return true;
      if (event.category === "clothing" && output.some((option) => option.available && option.fixedOption) && variantOnly && prompts.every((value, index) => index === 0 && parentRoleKnown || explicitVariant(value))) return true;
      const first = preferredSizes(event, settings)?.[0];
      if (!first || ["FREE", "F", "ONESIZE", "OS", "\uD504\uB9AC", "\uD504\uB9AC\uC0AC\uC774\uC988"].includes(compact(first))) return false;
      const decision2 = evaluateEvent({ ...event, options: output, requiresManualReview: false }, settings);
      return decision2.action === "apply" && decision2.option?.size !== null && compact(decision2.option?.size ?? "") === compact(first);
    };
    const walk = async (index, labels) => {
      const values = await choices(dialog, index);
      if (values.length > 50) throw new Error("\uC120\uD0DD \uAC00\uB2A5\uD55C \uC635\uC158\uC774 \uD655\uC778 \uBC94\uC704\uB97C \uB118\uC5C8\uC2B5\uB2C8\uB2E4.");
      const activePrompts = index === count - 1 ? boxes().map(text) : prompts;
      if (namedSizeSuffix && index === count - 1 && values.some((value) => !/^(?:SIZE\s*\d{1,2}|\d{1,2}\s*(?:SIZE|사이즈))$/i.test(value.label))) throw new Error("S \uC120\uD0DD\uB780\uC758 \uC22B\uC790 \uC0AC\uC774\uC988 \uD45C\uAE30\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      for (const item of values) {
        if (index === count - 1) {
          add([...labels, item.label], item.available, activePrompts);
          if (output.length > 200) throw new Error("\uC635\uC158 \uC870\uD569\uC774 \uD655\uC778 \uBC94\uC704\uB97C \uB118\uC5C8\uC2B5\uB2C8\uB2E4.");
          if (event.category === "clothing" && settings.allowFreeSize && count === 2 && parentRoleKnown && labels[0] === firstProduct && item.available && output.at(-1)?.size === "FREE" && values.filter((value) => value.available).length === 1 && fixedOption(event, information, labels[0])) {
            verifiedFixed = true;
            return;
          }
        } else if (item.available) {
          if (index === 0 && parentRoleKnown && firstProduct === null) firstProduct = item.label;
          await choose(dialog, index, item.label);
          if (boxes().length !== count) {
            const complete = buttons("\uC120\uD0DD \uC644\uB8CC", dialog);
            const fixed = index === 0 && parentRoleKnown && boxes().length === 1 && complete.length === 1 && enabled(complete[0]) ? fixedOption(event, information, item.label) : null;
            if (!fixed) throw new Error("\uC0C1\uD488 \uBCC0\uACBD \uD6C4 \uACF5\uC2DD \uB2E8\uC77C \uC635\uC158\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
            output.push(fixed);
            return;
          }
          await walk(index + 1, [...labels, item.label]);
        }
        if (satisfied()) return;
      }
    };
    await walk(0, []);
    return output;
  }
  async function inspect(message) {
    inspectionState = null;
    const input = message.event;
    eventPath(input);
    const settings = message.settings;
    if (!settings || !hasCurrentApplicationConsent(settings)) throw new Error("\uD544\uC218 \uB3D9\uC758\uC640 \uC2E0\uCCAD \uC870\uAC74\uC744 \uBA3C\uC800 \uC124\uC815\uD574 \uC8FC\uC138\uC694.");
    await waitFor(() => eventInfo("\uBAA8\uC9D1\uAE30\uAC04"), 1e4);
    const information = await eventInformation(input);
    const classification = classified(input, information, message.productClassifications);
    const logo = nodes('img[alt$=" \uB85C\uACE0 \uC774\uBBF8\uC9C0"]')[0];
    const event = { ...classification.event, brand: input.brand || logo?.alt.replace(/ 로고 이미지$/, "") || "", deadline: parseDeadline(eventInfo("\uBAA8\uC9D1\uAE30\uAC04")), reviewDeadline: parseDeadline(eventInfo("\uD6C4\uAE30 \uC791\uC131 \uAE30\uAC04")), status: "unavailable", eligible: null, options: [], requirements: [], requiresManualReview: true };
    if (classification.needsClassification) return { event, productUrls: classification.productUrls, needsClassification: true };
    if (event.category === "kids" || settings.excludedCategories.includes(event.category)) return { event, selectedOption: null };
    if (event.deadline && Date.parse(event.deadline) <= Date.now()) return { event: { ...event, status: "closed" }, selectedOption: null };
    await waitFor(() => buttons(APPLY).length || buttons(APPLIED).length, 5e3);
    if (buttons(APPLIED).length) return { event: { ...event, status: "applied" }, selectedOption: null };
    const apply = one(buttons(APPLY), "\uC2E0\uCCAD \uBC84\uD2BC\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    if (!enabled(apply)) return { event: { ...event, reason: "\uBB34\uC2E0\uC0AC\uC5D0\uC11C \uC2E0\uCCAD \uBC84\uD2BC\uC744 \uD5C8\uC6A9\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4." }, selectedOption: null };
    let dialog = nodes('[role="dialog"]').filter(visible)[0];
    if (!dialog) {
      click(apply);
      dialog = await waitFor(() => nodes('[role="dialog"]').filter(visible)[0], 5e3);
    }
    event.status = "open";
    event.eligible = true;
    event.options = await readOptions(dialog, event, settings, information);
    event.requiresManualReview = !event.options.length || !event.deadline || !event.reviewDeadline;
    event.reason = !event.options.length ? "\uC0C1\uD488 \uC120\uD0DD\uC9C0\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4." : !event.deadline || !event.reviewDeadline ? "\uBAA8\uC9D1 \uB610\uB294 \uD6C4\uAE30 \uC791\uC131 \uAE30\uAC04\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4." : "";
    const decision2 = evaluateEvent(event, settings);
    if (decision2.action === "apply" && decision2.option) inspectionState = { event: structuredClone(event), selectedOption: structuredClone(decision2.option), dialog, url: location.href, expiresAt: Date.now() + 6e4 };
    return { event, selectedOption: decision2.option, decision: decision2.action, reason: decision2.reason };
  }
  async function consentHash(id, value, brand) {
    if (id === "privacy_third_party") {
      const recipient = /(\[필수\] 제공 받는 자\s*[・·]\s*)([^\n]+)/.exec(value);
      if (!recipient?.[2] || !brand || normalize(recipient[2]) !== normalize(brand)) return null;
      value = value.replace(recipient[0], `${recipient[1]}{EVENT_BRAND}`);
    }
    return hash(normalize(value));
  }
  async function formFingerprint() {
    const root = one(nodes(".preuser-apply-detail"), "\uC2E0\uCCAD \uC591\uC2DD\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    return hash(JSON.stringify({ text: normalize(text(root)), fields: nodes("input,textarea,select", root).map((field) => ({ tag: field.tagName, id: field.id, name: field.getAttribute("name"), type: field.getAttribute("type"), placeholder: field.getAttribute("placeholder"), readonly: field.hasAttribute("readonly"), disabled: field.hasAttribute("disabled"), deliveryRequest: field instanceof HTMLInputElement && field.readOnly && field.placeholder === "\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694" ? field.value : void 0 })), consents: nodes('[role="checkbox"]', root).map((field) => ({ id: field.id, label: text(field.parentElement) })) }));
  }
  async function validateForm(brand) {
    const address = one(buttons("\uBC30\uC1A1\uC9C0 \uBCC0\uACBD"), "\uBB34\uC2E0\uC0AC\uC5D0 \uBC30\uC1A1\uC9C0\uB97C \uB4F1\uB85D\uD574 \uC8FC\uC138\uC694.");
    const block = address.parentElement?.parentElement;
    const name = text(block?.children[0]?.children[0]?.children[0] ?? null);
    const street = text(block?.children[1] ?? null);
    const contact = text(block?.children[2] ?? null);
    if (!name || street.length <= 5 || !/(?:01\d)[-\s]?\d{3,4}[-\s]?\d{4}/.test(contact)) throw new Error("\uB4F1\uB85D\uB41C \uC774\uB984\xB7\uC5F0\uB77D\uCC98\xB7\uBC30\uC1A1\uC9C0\uB97C \uD655\uC778\uD574 \uC8FC\uC138\uC694.");
    const checkboxes = nodes('[role="checkbox"]');
    const expected = ["all", ...REQUIRED.map((item) => item.id)];
    if (checkboxes.length !== expected.length || checkboxes.some((item, index) => item.id !== expected[index])) throw new Error("\uD544\uC218 \uB3D9\uC758 \uD56D\uBAA9\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    const unknown = nodes("input,textarea,select").some((field) => {
      if (/(?:resident|rrn|jumin|주민|tax|제세)/i.test(`${field.getAttribute("name") ?? ""} ${field.id} ${field.getAttribute("placeholder") ?? ""}`)) return true;
      return field instanceof HTMLInputElement ? !field.disabled && field.type !== "hidden" && !(field.readOnly && field.placeholder === "\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694") : true;
    });
    if (unknown) throw new Error("\uCD94\uAC00 \uAC1C\uC778\uC815\uBCF4 \uB610\uB294 \uC785\uB825 \uD56D\uBAA9\uC744 \uC9C1\uC811 \uD655\uC778\uD574\uC57C \uD569\uB2C8\uB2E4.");
    const details = buttons("\uC790\uC138\uD788");
    if (details.length !== REQUIRED.length) throw new Error("\uD544\uC218 \uB3D9\uC758 \uC0C1\uC138 \uB0B4\uC6A9\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    for (let index = 0; index < REQUIRED.length; index++) {
      const approved = REQUIRED[index];
      const label = normalize(text(checkboxes[index + 1].parentElement));
      click(details[index]);
      const modal = await waitFor(() => nodes(CONSENT_MODAL).filter(visible)[0], 5e3);
      const fingerprint = await consentHash(approved.id, modal.innerText, brand);
      const close = one(buttons(/.*/, modal), "\uB3D9\uC758 \uC0C1\uC138 \uCC3D\uC744 \uB2EB\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      click(close);
      await waitFor(() => !visible(modal), 5e3);
      if (label !== normalize(approved.label) || fingerprint !== approved.hash) throw new Error("\uD544\uC218 \uC815\uCC45 \uB0B4\uC6A9 \uB610\uB294 \uC815\uBCF4\uB97C \uC81C\uACF5\uD560 \uBE0C\uB79C\uB4DC\uAC00 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    }
    one(buttons("\uC2E0\uCCAD \uC644\uB8CC"), "\uC2E0\uCCAD \uC644\uB8CC \uBC84\uD2BC\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
  }
  async function delivery(requested) {
    if (!requested?.trim()) return;
    const choice = DELIVERY_REQUEST_OPTIONS.find((value) => compact(value) === compact(requested));
    if (!choice) throw new Error("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D\uC785\uB2C8\uB2E4.");
    const input = one(nodes('input[placeholder="\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694"]'), "\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D \uC120\uD0DD\uB780\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    if (!input.readOnly) throw new Error("\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D \uC120\uD0DD\uB780\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    if (compact(input.value) === compact(choice)) return;
    click(input);
    const dialog = await waitFor(() => nodes('[role="dialog"]').find((element) => visible(element) && text(element).includes("\uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D")), 5e3);
    click(one(buttons(choice, dialog), "\uC124\uC815\uD55C \uBC30\uC1A1 \uC694\uCCAD\uC0AC\uD56D\uC744 \uC120\uD0DD\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4."));
    await waitFor(() => compact(input.value) === compact(choice), 5e3);
  }
  async function prepare(message) {
    const event = message.event;
    const settings = message.settings;
    if (!settings?.enabled || settings.mode !== "live" || !hasCurrentApplicationConsent(settings)) throw new Error("\uC790\uB3D9 \uC2E0\uCCAD\uACFC \uD544\uC218 \uB3D9\uC758\uB97C \uBA3C\uC800 \uCF1C \uC8FC\uC138\uC694.");
    if (/^\/preuser\/events\//.test(location.pathname)) {
      eventPath(event);
      const cache = inspectionState;
      const inspected = cache && cache.url === location.href && cache.event.id === event.id && cache.expiresAt > Date.now() && cache.dialog.isConnected && visible(cache.dialog) ? { event: cache.event, selectedOption: cache.selectedOption } : await inspect(message);
      if ("needsClassification" in inspected && inspected.needsClassification) return inspected;
      const detail = inspected.event;
      const chosen = inspected.selectedOption;
      if (!chosen || !message.option || JSON.stringify(chosen) !== JSON.stringify(message.option)) throw new Error("\uC120\uD0DD\uD55C \uC0C1\uD488 \uC635\uC158\uC774 \uBC14\uB00C\uC5B4 \uB2E4\uC2DC \uD655\uC778\uD574\uC57C \uD569\uB2C8\uB2E4.");
      const freshDecision = evaluateEvent(detail, settings);
      if (freshDecision.action !== "apply" || freshDecision.option?.id !== chosen.id || detail.deadline !== parseDeadline(eventInfo("\uBAA8\uC9D1\uAE30\uAC04")) || detail.reviewDeadline !== parseDeadline(eventInfo("\uD6C4\uAE30 \uC791\uC131 \uAE30\uAC04")) || buttons(APPLIED).length) throw new Error("\uC0C1\uD488 \uC2E0\uCCAD \uC870\uAC74\uC774\uB098 \uAE30\uAC04\uC774 \uBC14\uB00C\uC5C8\uC2B5\uB2C8\uB2E4.");
      inspectionState = null;
      const dialog = one(nodes('[role="dialog"]').filter(visible), "\uC0C1\uD488 \uC120\uD0DD \uCC3D\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      const labels = JSON.parse(chosen.id);
      if (!Array.isArray(labels) || labels.some((label) => typeof label !== "string")) throw new Error("\uC0C1\uD488 \uC635\uC158 \uD45C\uAE30\uAC00 \uC798\uBABB\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
      for (let index = 0; index < labels.length; index++) await choose(dialog, index, labels[index]);
      const complete = one(buttons("\uC120\uD0DD \uC644\uB8CC", dialog), "\uC635\uC158 \uC120\uD0DD \uC644\uB8CC \uBC84\uD2BC\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      if (labels.length !== nodes(DROPDOWN, dialog).length || !enabled(complete)) throw new Error("\uC0C1\uD488 \uC635\uC158 \uAD6C\uC131\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
      const currentUrl = location.href;
      deferredEffect = () => {
        if (location.href === currentUrl && visible(dialog) && enabled(complete)) complete.click();
      };
      return { stage: "apply-navigation", event: detail, option: chosen, nextUrl: `${ORIGIN}/preuser/apply/${event.id}`, navigationPending: true };
    }
    eventPath(event, true);
    prepared = null;
    await waitFor(() => nodes("#privacy_collection").some(visible), 1e4);
    await validateForm(event.brand);
    await delivery(settings.deliveryRequest);
    eventPath(event, true);
    const key = crypto.randomUUID();
    const fingerprint = await formFingerprint();
    prepared = { key, eventId: event.id, url: location.href, fingerprint, expiresAt: Date.now() + 6e4 };
    return { stage: "prepared", preparedKey: key, fingerprint, expiresAt: prepared.expiresAt, eventId: event.id };
  }
  function checked(element) {
    return element instanceof HTMLInputElement ? element.checked : element.getAttribute("aria-checked") === "true" || element.getAttribute("data-state") === "checked";
  }
  async function commit(message) {
    const event = message.event;
    eventPath(event, true);
    const settings = message.settings;
    const capability = prepared;
    prepared = null;
    if (!capability || capability.key !== message.preparedKey || capability.eventId !== event.id || capability.url !== location.href || capability.expiresAt <= Date.now() || !settings?.enabled || settings.mode !== "live" || !hasCurrentApplicationConsent(settings) || typeof message.guardToken !== "string" || message.guardToken.length < 16) throw new Error("\uC2E0\uCCAD \uD654\uBA74 \uB610\uB294 \uD544\uC218 \uC2B9\uC778\uC774 \uB9CC\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
    const unchanged = async () => {
      eventPath(event, true);
      return capability.url === location.href && capability.expiresAt > Date.now() && await formFingerprint() === capability.fingerprint;
    };
    if (!await unchanged()) throw new Error("\uC2E0\uCCAD \uD654\uBA74\uC774 \uBC14\uB00C\uC5B4 \uC81C\uCD9C \uC804\uC5D0 \uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4.");
    for (const consent of REQUIRED) {
      const checkbox = one(nodes(`#${consent.id}`), "\uD544\uC218 \uB3D9\uC758 \uD56D\uBAA9\uC774 \uBCC0\uACBD\uB418\uC5C8\uC2B5\uB2C8\uB2E4.");
      if (!checked(checkbox)) {
        click(checkbox);
        await waitFor(() => checked(checkbox), 3e3);
      }
    }
    if (!await unchanged()) throw new Error("\uC2E0\uCCAD \uC9C1\uC804 \uD654\uBA74\uC774 \uBC14\uB00C\uC5B4 \uC81C\uCD9C\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    const submit = one(buttons("\uC2E0\uCCAD \uC644\uB8CC"), "\uC2E0\uCCAD \uC644\uB8CC \uBC84\uD2BC\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    if (!enabled(submit)) throw new Error("\uC2E0\uCCAD \uC644\uB8CC \uBC84\uD2BC\uC744 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    const guard = await chrome.runtime.sendMessage({ type: "musinsazima-guard", action: "verify", eventId: event.id, preparedKey: capability.key, guardToken: message.guardToken });
    eventPath(event, true);
    if (guard?.ok !== true || capability.url !== location.href || capability.expiresAt <= Date.now() || !visible(submit) || !enabled(submit)) throw new Error("\uC2E0\uCCAD \uAD8C\uD55C \uB610\uB294 \uC790\uB3D9\uD654 \uC124\uC815\uC774 \uBCC0\uACBD\uB418\uC5B4 \uC911\uC9C0\uD588\uC2B5\uB2C8\uB2E4.");
    submit.click();
    const completionSignal = await waitFor(() => location.pathname !== `/preuser/apply/${event.id}` || buttons(/^(?:신청 취소|신청취소|신청 내역 확인)$/).length > 0 || nodes('[role="dialog"]').some((dialog) => visible(dialog) && /신청(?:이|을)?\s*완료(?:되었|했|되었습니다|됐)/.test(normalize(text(dialog)))), 5e3).then(() => true).catch(() => false);
    return { status: "unknown", clicked: true, completionSignal, eventId: event.id, reason: "\uC81C\uCD9C \uBC84\uD2BC\uC744 \uD55C \uBC88 \uB20C\uB800\uC2B5\uB2C8\uB2E4. \uC0C1\uC138 \uD654\uBA74\uC5D0\uC11C \uC2E0\uCCAD \uC644\uB8CC \uC0C1\uD0DC\uB97C \uD655\uC778\uD569\uB2C8\uB2E4." };
  }
  async function reconcile(message) {
    eventPath(message.event);
    await waitFor(() => buttons(APPLIED).length || buttons(APPLY).length, 8e3);
    return buttons(APPLIED).length ? { status: "confirmed", reason: "\uACF5\uC2DD \uC0C1\uC138 \uD654\uBA74\uC5D0\uC11C \uC2E0\uCCAD \uC644\uB8CC\uB97C \uD655\uC778\uD588\uC2B5\uB2C8\uB2E4." } : { status: "unknown", reason: "\uC2E0\uCCAD \uC644\uB8CC \uC5EC\uBD80\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uAC19\uC740 \uD56D\uBAA9\uC744 \uB2E4\uC2DC \uC81C\uCD9C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4." };
  }
  async function handleContentMessage(message) {
    officialPath(/^\/(?:preuser\/(?:main|events\/\d+|apply\/\d+)|products\/\d+)\/?$/);
    if (message.action === "session") return session();
    if (message.action === "catalog") return catalog();
    if (message.action === "product") return readProduct();
    if (message.action === "inspect") return inspect(message);
    if (message.action === "prepare") return prepare(message);
    if (message.action === "commit") return commit(message);
    if (message.action === "reconcile") return reconcile(message);
    throw new Error("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uD655\uC7A5 \uAE30\uB2A5 \uC694\uCCAD\uC785\uB2C8\uB2E4.");
  }
  function registerListener() {
    if (typeof chrome === "undefined" || typeof window === "undefined" || !chrome.runtime?.id) return;
    const scope = globalThis;
    const previous = scope.__musinsazimaContentListenerV1;
    if (previous && previous.extensionId === chrome.runtime.id && previous.alive()) return;
    const runtime = chrome.runtime;
    const extensionId = runtime.id;
    scope.__musinsazimaContentListenerV1 = { extensionId, alive: () => {
      try {
        return runtime.id === extensionId;
      } catch {
        return false;
      }
    } };
    runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message?.type !== "musinsazima-content" || sender?.id !== chrome.runtime.id || window.top !== window) return false;
      if (busy) {
        sendResponse({ ok: false, error: "\uC774 \uD654\uBA74\uC5D0\uC11C \uB2E4\uB978 \uC791\uC5C5\uC744 \uC9C4\uD589 \uC911\uC785\uB2C8\uB2E4." });
        return false;
      }
      busy = true;
      deferredEffect = null;
      void handleContentMessage(message).then((result) => {
        const effect = deferredEffect;
        deferredEffect = null;
        sendResponse({ ok: true, data: result });
        if (effect) setTimeout(() => {
          try {
            effect();
          } catch {
          }
        }, 150);
      }, (error) => {
        deferredEffect = null;
        sendResponse({ ok: false, error: error instanceof Error && /^[가-힣]/.test(error.message) ? error.message.slice(0, 240) : "\uBB34\uC2E0\uC0AC \uD654\uBA74\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC5F0\uACB0\uD574 \uC8FC\uC138\uC694.", ...error instanceof CatalogNeedsForeground ? { code: error.code } : {} });
      }).finally(() => {
        busy = false;
      });
      return true;
    });
  }
  registerListener();
})();
